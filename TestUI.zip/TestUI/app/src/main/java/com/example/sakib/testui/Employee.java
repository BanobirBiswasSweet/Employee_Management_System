package com.example.sakib.testui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Employee extends AppCompatActivity {

    private Button btn_entry, btn_register_employee, btn_list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee);

        btn_list = (Button) findViewById(R.id.btn_list);
        btn_register_employee = (Button) findViewById(R.id.btn_register_employee);
        btn_entry = (Button) findViewById(R.id.btn_entry);

        btn_register_employee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_register = new Intent(Employee.this, RegisterEmployee.class);
                startActivity(intent_register);
            }
        });
    }
}
