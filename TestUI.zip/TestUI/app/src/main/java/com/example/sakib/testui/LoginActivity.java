package com.example.sakib.testui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private EditText et_admin_username, et_admin_pass;
    private Button btn_login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        et_admin_username = (EditText) findViewById(R.id.et_admin_username);
        et_admin_pass = (EditText) findViewById(R.id.et_admin_pass);
        btn_login = (Button) findViewById(R.id.btn_login);

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = et_admin_username.getText().toString();
                String pass = et_admin_pass.getText().toString();

                if (username.equals("admin") && pass.equals("123")){
                    Toast.makeText(LoginActivity.this, "Succesful!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginActivity.this, Employee.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(LoginActivity.this, "Wrong Credentials! Try again", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
}
