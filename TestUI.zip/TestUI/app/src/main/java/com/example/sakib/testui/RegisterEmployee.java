package com.example.sakib.testui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class RegisterEmployee extends AppCompatActivity {

    private EditText et_em_id, et_em_name, et_em_dept, et_em_desig, et_em_phone, et_em_email, et_em_jdate, et_em_salary;
    private Button btn_em_register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_employee);

        et_em_id = (EditText) findViewById(R.id.et_em_id);
        et_em_name = (EditText) findViewById(R.id.et_em_name);
        et_em_dept = (EditText) findViewById(R.id.et_em_dept);
        et_em_desig = (EditText) findViewById(R.id.et_em_desig);
        et_em_phone = (EditText) findViewById(R.id.et_em_phone);
        et_em_email = (EditText) findViewById(R.id.et_em_email);
        et_em_jdate = (EditText) findViewById(R.id.et_em_jdate);
        et_em_salary = (EditText) findViewById(R.id.et_em_salary);
        btn_em_register = (Button) findViewById(R.id.btn_em_register);


    }
}
