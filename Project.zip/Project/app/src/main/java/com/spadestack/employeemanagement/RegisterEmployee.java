package com.spadestack.employeemanagement;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class RegisterEmployee extends AppCompatActivity {

    EditText et_eid, et_ename, et_phone, et_email, et_did, et_designation, et_salary, et_jdate;
    Button btn_register_employee;
    final Calendar myCalendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_employee);

        et_eid = (EditText) findViewById(R.id.et_eid);
        et_ename = (EditText) findViewById(R.id.et_ename);
        et_phone = (EditText) findViewById(R.id.et_phone);
        et_email = (EditText) findViewById(R.id.et_email);
        et_did = (EditText) findViewById(R.id.et_did);
        et_designation = (EditText) findViewById(R.id.et_designation);
        et_salary = (EditText) findViewById(R.id.et_salary);
        et_jdate = (EditText) findViewById(R.id.et_jdate);
        btn_register_employee = (Button) findViewById(R.id.btn_register_employee);

        final Calendar myCalendar = Calendar.getInstance();

        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }
            private void updateLabel(){
                String myFormat = "MM/dd/yy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                et_jdate.setText(sdf.format(myCalendar.getTime()));
            }

        };


        et_jdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(RegisterEmployee.this, date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });


    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    public void send(View v){

        new Send().execute();

    }



    public class Send extends AsyncTask<String, Void,Long > {



        protected Long doInBackground(String... urls) {

            String Name=name.getText().toString();
            String Email=email.getText().toString();
            String Number=number.getText().toString();

            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("https://kazisakib.000webhostapp.com/phpcode.php");

            try {
                // Add your data
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("Name", Name));
                nameValuePairs.add(new BasicNameValuePair("Email", Email));
                nameValuePairs.add(new BasicNameValuePair("Number", Number));
                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));



                // Execute HTTP Post Request
                HttpResponse response = httpclient.execute(httppost);

            } catch (Exception e) {
                // TODO Auto-generated catch block
            }
            return null;

        }
        protected void onProgressUpdate(Integer... progress) {

        }

        protected void onPostExecute(Long result) {

        }
    }

}
