package com.spadestack.employeemanagement;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class employee extends AppCompatActivity {

    Button btn_register, btn_entry, btn_report, btn_quit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee);

        btn_register = (Button) findViewById(R.id.btn_register_employee);
        btn_entry = (Button) findViewById(R.id.btn_entry);
        btn_report = (Button) findViewById(R.id.btn_report);
        btn_quit = (Button) findViewById(R.id.btn_quit);


        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(employee.this, RegisterEmployee.class);
                startActivity(intent2);
            }
        });
    }
}
